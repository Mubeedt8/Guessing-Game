const secretNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;

function checkGuess() {
  const guess = parseInt(document.getElementById("guessInput").value);
  const message = document.getElementById("message");
  const successSound = document.getElementById("successSound");
  const errorSound = document.getElementById("errorSound");
  attempts++;

  if (isNaN(guess) || guess < 1 || guess > 100) {
    message.textContent = "Enter a number between 1 and 100.";
    errorSound.play();
    animate(message);
    return;
  }

  if (guess < secretNumber) {
    message.textContent = "Too low!";
    errorSound.play();
  } else if (guess > secretNumber) {
    message.textContent = "Too high!";
    errorSound.play();
  } else {
    message.textContent = \`Correct! It was \${secretNumber} in \${attempts} tries.\`;
    successSound.play();
  }

  animate(message);
}

function animate(element) {
  element.style.transform = "scale(1.1)";
  setTimeout(() => {
    element.style.transform = "scale(1)";
  }, 150);
}